/****************************************************************************
 * hai1.c
 *
 * Ci�ncia da Computa��o 50
 * Gabriel Lima Guimar�es
 *
 * Fala oi para o mundo
 *
 * Demonstra o uso de printf.
 ***************************************************************************/
       
#include <stdio.h>

int
main(void)
{
    printf("O hai, world!\n");
}
