/****************************************************************************
 * hai2.c
 *
 * Ci�ncia da Computa��o 50
 * Gabriel Lima Guimar�es
 *
 * S� fala oi para o Gabriel.
 *
 * Demonstra o uso da Biblioteca do CC50 (string)
 ***************************************************************************/
       
#include <cc50.h>
#include <stdio.h>

int
main(void)
{
    string name = "Gabriel";
    printf("O hai, %s!\n", name);
}
