<?
    echo "Hello, world!\n";
?>
